var current_url = "https://localhost:7241"; 
var current_img = "https://localhost:7241/";